CREATE TABLE `df_internal_documents_registry` (
  `inr_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `inr_id_user` int(11) NOT NULL COMMENT 'Користувач, який зареєстрував документ',
  `inr_id_carrier_type` bigint(20) unsigned NOT NULL COMMENT 'Тип носія документа',
  `inr_id_document_location` bigint(20) unsigned DEFAULT NULL COMMENT 'Фізичне місцезнаходження оригінала',
  `inr_number` varchar(10) NOT NULL COMMENT 'Номер документа',
  `inr_additional_number` varchar(8) DEFAULT NULL COMMENT 'Додатковий номер',
  `inr_id_document_type` bigint(20) NOT NULL COMMENT 'Тип документа',
  `inr_id_title` bigint(20) unsigned NOT NULL COMMENT 'Назва чи заголовок документа',
  `inr_document_date` date DEFAULT NULL COMMENT 'Дата в документі',
  `inr_id_initiator` bigint(20) unsigned NOT NULL COMMENT 'Ініціатор (користувач)',
  `inr_id_recipient` bigint(20) unsigned DEFAULT NULL COMMENT 'Отримувач (користувач)',
  `inr_id_description` bigint(20) unsigned DEFAULT NULL COMMENT 'Опис або короткий зміст документа',
  `inr_file_extension` varchar(255) NOT NULL COMMENT 'Розширення файлу завантаженого документа',
  `inr_id_status` bigint(20) unsigned DEFAULT NULL COMMENT 'Статус документа (наприклад, "новий", "в обробці", "завершено")',
  `inr_id_responsible_user` bigint(20) unsigned DEFAULT NULL COMMENT 'id відповідального за виконання',
  `inr_id_assigned_departament` bigint(20) unsigned DEFAULT NULL COMMENT 'id відділа, якому призначено на виконання',
  `inr_id_assigned_user` bigint(20) unsigned DEFAULT NULL COMMENT 'Призначений користувач обробки документа.',
  `inr_date_of_receipt_by_executor` datetime DEFAULT NULL COMMENT 'Дата надходження виконавцю',
  `inr_id_execution_control` bigint(20) unsigned DEFAULT NULL COMMENT 'Контроль виконання: one-time, monthly, quarterly, annually',
  `inr_id_term_of_execution` bigint(20) unsigned DEFAULT NULL COMMENT 'Термін виконання в днях',
  `inr_control_date` datetime DEFAULT NULL COMMENT 'Дата, до якої документ має бути виконаним',
  `inr_execution_date` datetime DEFAULT NULL COMMENT 'Дата виконання документа',
  `inr_distribution_scope` bigint(20) unsigned DEFAULT NULL COMMENT 'Поширюється на',
  `inr_add_date` datetime NOT NULL,
  `inr_change_date` datetime NOT NULL,
  PRIMARY KEY (`inr_id`),
  UNIQUE KEY `uni_1` (`inr_number`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Регістр вихідних документів із основними даними';

INSERT INTO `df_internal_documents_registry` VALUES ('1', '1', '4', '1', '00000001', '3672', '2', '3', '2024-05-03', '50', '50', '1', 'png', '2', '47', '1', '59', '2024-06-09 08:49:48', '3', '1', '2024-06-04 00:00:00', '', '', '2024-05-29 00:00:00', '2024-06-09 08:49:48');
INSERT INTO `df_internal_documents_registry` VALUES ('2', '1', '1', '', '00000002', '', '1', '1', '2024-05-29', '1', '1', '1', 'png', '1', '1', '', '59', '2024-06-08 00:00:00', '1', '', '2024-06-30 00:00:00', '2024-06-09 00:00:00', '', '2024-05-29 00:00:00', '2024-06-14 19:02:59');
