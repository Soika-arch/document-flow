CREATE TABLE `df_document_locations` (
  `dlc_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dlc_id_user` bigint(20) unsigned NOT NULL,
  `dlc_name` varchar(255) NOT NULL,
  `dlc_add_date` datetime NOT NULL,
  `dlc_change_date` datetime NOT NULL,
  PRIMARY KEY (`dlc_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Назви місцезнаходжень оригіналів документів';

