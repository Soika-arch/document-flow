CREATE TABLE `df_outgoing_documents_registry` (
  `odr_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `odr_id_user` bigint(20) unsigned NOT NULL COMMENT 'Користувач, який зареєстрував документ',
  `odr_id_document_type` bigint(20) unsigned NOT NULL COMMENT 'Тип документа',
  `odr_id_carrier_type` bigint(20) unsigned NOT NULL COMMENT 'Тип носія документа',
  `odr_id_document_location` bigint(20) unsigned DEFAULT NULL COMMENT 'Фізичне місцезнаходження оригінала',
  `odr_number` varchar(10) NOT NULL COMMENT 'Номер вихідного документа',
  `odr_id_incoming_number` bigint(20) unsigned DEFAULT NULL COMMENT 'Номер відповідного вхідного',
  `odr_registration_form_number` varchar(255) DEFAULT NULL COMMENT 'Реєстраційний номер бланка',
  `odr_id_title` bigint(20) unsigned NOT NULL COMMENT 'Назва чи заголовок документа',
  `odr_document_date` date DEFAULT NULL COMMENT 'Дата в документі',
  `odr_id_sender` bigint(20) unsigned NOT NULL COMMENT 'Відправник (користувач)',
  `odr_id_recipient` bigint(20) unsigned DEFAULT NULL COMMENT 'Отримувач (зовнішний)',
  `odr_id_description` bigint(20) unsigned DEFAULT NULL COMMENT 'Опис або короткий зміст документа',
  `odr_file_extension` varchar(255) NOT NULL COMMENT 'Розширення файлу завантаженого документа',
  `odr_id_status` bigint(20) unsigned DEFAULT NULL COMMENT 'Статус документа (наприклад, "новий", "в обробці", "завершено")',
  `odr_id_assigned_user` bigint(20) unsigned DEFAULT NULL COMMENT 'Призначений користувач обробки документа.',
  `odr_id_execution_control` bigint(20) unsigned DEFAULT NULL COMMENT 'Контроль виконання: one-time, monthly, quarterly, annually',
  `odr_control_date` datetime DEFAULT NULL COMMENT 'Дата, до якої документ має бути виконаним',
  `odr_execution_date` datetime DEFAULT NULL COMMENT 'Дата виконання документа',
  `odr_add_date` datetime NOT NULL,
  `odr_change_date` datetime NOT NULL,
  PRIMARY KEY (`odr_id`),
  UNIQUE KEY `uni_1` (`odr_number`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Регістр вихідних документів із основними даними';

INSERT INTO `df_outgoing_documents_registry` VALUES ('1', '1', '1', '4', '4', '00000002', '4', '1234', '4', '2024-05-01', '1', '1', '12', 'png', '1', '', '2', '2024-06-09 00:00:00', '', '2024-05-26 00:00:00', '2024-05-31 17:37:37');
INSERT INTO `df_outgoing_documents_registry` VALUES ('2', '1', '8', '1', '', '00000012', '', '', '1', '2024-05-28', '50', '1', '1', 'png', '1', '', '', '', '', '2024-05-28 17:19:39', '2024-05-28 17:19:39');
