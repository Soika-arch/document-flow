CREATE TABLE `df_distribution_scopes` (
  `dsc_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`dsc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

