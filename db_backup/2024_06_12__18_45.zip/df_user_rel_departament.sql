CREATE TABLE `df_user_rel_departament` (
  `urd_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `urd_id_user` bigint(20) unsigned NOT NULL,
  `urd_id_departament` bigint(20) unsigned NOT NULL,
  `urd_add_date` datetime NOT NULL,
  `urd_change_date` datetime NOT NULL,
  PRIMARY KEY (`urd_id`),
  KEY `urd_user` (`urd_id_user`),
  KEY `urd_departament` (`urd_id_departament`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Зв''язки користувачів з департаментами';

