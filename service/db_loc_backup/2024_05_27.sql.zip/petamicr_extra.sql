
--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `df_departments`
--
ALTER TABLE `df_departments`
  ADD PRIMARY KEY (`dp_id`);

--
-- Индексы таблицы `df_distribution_scopes`
--
ALTER TABLE `df_distribution_scopes`
  ADD PRIMARY KEY (`dsc_id`);

--
-- Индексы таблицы `df_document_carrier_types`
--
ALTER TABLE `df_document_carrier_types`
  ADD PRIMARY KEY (`cts_id`);

--
-- Индексы таблицы `df_document_control_types`
--
ALTER TABLE `df_document_control_types`
  ADD PRIMARY KEY (`dct_id`),
  ADD UNIQUE KEY `uni_1` (`dct_name`);

--
-- Индексы таблицы `df_document_descriptions`
--
ALTER TABLE `df_document_descriptions`
  ADD PRIMARY KEY (`dds_id`);

--
-- Индексы таблицы `df_document_locations`
--
ALTER TABLE `df_document_locations`
  ADD PRIMARY KEY (`dlc_id`);

--
-- Индексы таблицы `df_document_resolutions`
--
ALTER TABLE `df_document_resolutions`
  ADD PRIMARY KEY (`drs_id`);

--
-- Индексы таблицы `df_document_senders`
--
ALTER TABLE `df_document_senders`
  ADD PRIMARY KEY (`dss_id`),
  ADD UNIQUE KEY `uni_1` (`dss_name`);

--
-- Индексы таблицы `df_document_statuses`
--
ALTER TABLE `df_document_statuses`
  ADD PRIMARY KEY (`dst_id`),
  ADD UNIQUE KEY `uni_1` (`dst_name`);

--
-- Индексы таблицы `df_document_titles`
--
ALTER TABLE `df_document_titles`
  ADD PRIMARY KEY (`dts_id`);

--
-- Индексы таблицы `df_document_types`
--
ALTER TABLE `df_document_types`
  ADD PRIMARY KEY (`dt_id`);

--
-- Индексы таблицы `df_incoming_documents_registry`
--
ALTER TABLE `df_incoming_documents_registry`
  ADD PRIMARY KEY (`idr_id`),
  ADD UNIQUE KEY `uni_1` (`idr_number`),
  ADD KEY `idr_document_format` (`idr_id_carrier_type`),
  ADD KEY `idr_assigned_departament` (`idr_id_assigned_departament`),
  ADD KEY `idr_description` (`idr_id_description`),
  ADD KEY `idr_document_type` (`idr_id_document_type`),
  ADD KEY `idr_outgoing_number` (`idr_id_outgoing_number`),
  ADD KEY `idr_resolution` (`idr_id_resolution`),
  ADD KEY `idr_responsible_user` (`idr_id_responsible_user`),
  ADD KEY `idr_sender` (`idr_id_sender`),
  ADD KEY `idr_status` (`idr_id_status`),
  ADD KEY `idr_title` (`idr_id_title`),
  ADD KEY `idr_user` (`idr_id_user`),
  ADD KEY `idr_document_location` (`idr_id_document_location`),
  ADD KEY `idr_assigned_user` (`idr_id_assigned_user`),
  ADD KEY `idr_execution_control` (`idr_id_execution_control`),
  ADD KEY `idr_term_of_execution` (`idr_id_term_of_execution`),
  ADD KEY `idr_recipient` (`idr_id_recipient`);

--
-- Индексы таблицы `df_internal_documents_registry`
--
ALTER TABLE `df_internal_documents_registry`
  ADD PRIMARY KEY (`inr_id`),
  ADD UNIQUE KEY `uni_1` (`inr_number`);

--
-- Индексы таблицы `df_outgoing_documents_registry`
--
ALTER TABLE `df_outgoing_documents_registry`
  ADD PRIMARY KEY (`odr_id`),
  ADD UNIQUE KEY `uni_1` (`odr_number`),
  ADD KEY `odr_registration_form_number` (`odr_registration_form_number`);

--
-- Индексы таблицы `df_registration_forms`
--
ALTER TABLE `df_registration_forms`
  ADD PRIMARY KEY (`rf_id`),
  ADD UNIQUE KEY `uni_1` (`rf_name`);

--
-- Индексы таблицы `df_terms_of_execution`
--
ALTER TABLE `df_terms_of_execution`
  ADD PRIMARY KEY (`toe_id`),
  ADD UNIQUE KEY `uni_1` (`toe_name`);

--
-- Индексы таблицы `df_users`
--
ALTER TABLE `df_users`
  ADD PRIMARY KEY (`us_id`),
  ADD UNIQUE KEY `uni_1` (`us_login`);

--
-- Индексы таблицы `df_users_rel_statuses`
--
ALTER TABLE `df_users_rel_statuses`
  ADD PRIMARY KEY (`usr_id`),
  ADD UNIQUE KEY `uni_1` (`usr_id_user`,`usr_id_status`),
  ADD KEY `usr_status` (`usr_id_status`);

--
-- Индексы таблицы `df_user_document_access`
--
ALTER TABLE `df_user_document_access`
  ADD PRIMARY KEY (`uda_id`);

--
-- Индексы таблицы `df_user_rel_departament`
--
ALTER TABLE `df_user_rel_departament`
  ADD PRIMARY KEY (`urd_id`),
  ADD KEY `urd_user` (`urd_id_user`),
  ADD KEY `urd_departament` (`urd_id_departament`);

--
-- Индексы таблицы `df_user_statuses`
--
ALTER TABLE `df_user_statuses`
  ADD PRIMARY KEY (`uss_id`),
  ADD UNIQUE KEY `uni_1` (`uss_name`);

--
-- Индексы таблицы `df_visitor_routes`
--
ALTER TABLE `df_visitor_routes`
  ADD PRIMARY KEY (`vr_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `df_departments`
--
ALTER TABLE `df_departments`
  MODIFY `dp_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `df_distribution_scopes`
--
ALTER TABLE `df_distribution_scopes`
  MODIFY `dsc_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `df_document_carrier_types`
--
ALTER TABLE `df_document_carrier_types`
  MODIFY `cts_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `df_document_control_types`
--
ALTER TABLE `df_document_control_types`
  MODIFY `dct_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `df_document_descriptions`
--
ALTER TABLE `df_document_descriptions`
  MODIFY `dds_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `df_document_locations`
--
ALTER TABLE `df_document_locations`
  MODIFY `dlc_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `df_document_resolutions`
--
ALTER TABLE `df_document_resolutions`
  MODIFY `drs_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `df_document_senders`
--
ALTER TABLE `df_document_senders`
  MODIFY `dss_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `df_document_statuses`
--
ALTER TABLE `df_document_statuses`
  MODIFY `dst_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `df_document_titles`
--
ALTER TABLE `df_document_titles`
  MODIFY `dts_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `df_document_types`
--
ALTER TABLE `df_document_types`
  MODIFY `dt_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT для таблицы `df_incoming_documents_registry`
--
ALTER TABLE `df_incoming_documents_registry`
  MODIFY `idr_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `df_internal_documents_registry`
--
ALTER TABLE `df_internal_documents_registry`
  MODIFY `inr_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `df_outgoing_documents_registry`
--
ALTER TABLE `df_outgoing_documents_registry`
  MODIFY `odr_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `df_registration_forms`
--
ALTER TABLE `df_registration_forms`
  MODIFY `rf_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `df_terms_of_execution`
--
ALTER TABLE `df_terms_of_execution`
  MODIFY `toe_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `df_users`
--
ALTER TABLE `df_users`
  MODIFY `us_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT для таблицы `df_users_rel_statuses`
--
ALTER TABLE `df_users_rel_statuses`
  MODIFY `usr_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT для таблицы `df_user_document_access`
--
ALTER TABLE `df_user_document_access`
  MODIFY `uda_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `df_user_rel_departament`
--
ALTER TABLE `df_user_rel_departament`
  MODIFY `urd_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `df_user_statuses`
--
ALTER TABLE `df_user_statuses`
  MODIFY `uss_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `df_visitor_routes`
--
ALTER TABLE `df_visitor_routes`
  MODIFY `vr_id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `df_incoming_documents_registry`
--
ALTER TABLE `df_incoming_documents_registry`
  ADD CONSTRAINT `idr_assigned_departament` FOREIGN KEY (`idr_id_assigned_departament`) REFERENCES `df_departments` (`dp_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_assigned_user` FOREIGN KEY (`idr_id_assigned_user`) REFERENCES `df_users` (`us_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_description` FOREIGN KEY (`idr_id_description`) REFERENCES `df_document_descriptions` (`dds_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_document_format` FOREIGN KEY (`idr_id_carrier_type`) REFERENCES `df_document_carrier_types` (`cts_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_document_location` FOREIGN KEY (`idr_id_document_location`) REFERENCES `df_departments` (`dp_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_document_type` FOREIGN KEY (`idr_id_document_type`) REFERENCES `df_document_types` (`dt_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_execution_control` FOREIGN KEY (`idr_id_execution_control`) REFERENCES `df_document_control_types` (`dct_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_outgoing_number` FOREIGN KEY (`idr_id_outgoing_number`) REFERENCES `df_outgoing_documents_registry` (`odr_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_recipient` FOREIGN KEY (`idr_id_recipient`) REFERENCES `df_users` (`us_id`) ON DELETE SET NULL ON UPDATE SET NULL,
  ADD CONSTRAINT `idr_resolution` FOREIGN KEY (`idr_id_resolution`) REFERENCES `df_document_resolutions` (`drs_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_responsible_user` FOREIGN KEY (`idr_id_responsible_user`) REFERENCES `df_users` (`us_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_sender` FOREIGN KEY (`idr_id_sender`) REFERENCES `df_document_senders` (`dss_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_status` FOREIGN KEY (`idr_id_status`) REFERENCES `df_document_statuses` (`dst_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_term_of_execution` FOREIGN KEY (`idr_id_term_of_execution`) REFERENCES `df_terms_of_execution` (`toe_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_title` FOREIGN KEY (`idr_id_title`) REFERENCES `df_document_titles` (`dts_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_user` FOREIGN KEY (`idr_id_user`) REFERENCES `df_users` (`us_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `df_outgoing_documents_registry`
--
ALTER TABLE `df_outgoing_documents_registry`
  ADD CONSTRAINT `odr_registration_form_number` FOREIGN KEY (`odr_registration_form_number`) REFERENCES `df_registration_forms` (`rf_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `df_users_rel_statuses`
--
ALTER TABLE `df_users_rel_statuses`
  ADD CONSTRAINT `usr_status` FOREIGN KEY (`usr_id_status`) REFERENCES `df_user_statuses` (`uss_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `usr_user` FOREIGN KEY (`usr_id_user`) REFERENCES `df_users` (`us_id`);

--
-- Ограничения внешнего ключа таблицы `df_user_rel_departament`
--
ALTER TABLE `df_user_rel_departament`
  ADD CONSTRAINT `urd_departament` FOREIGN KEY (`urd_id_departament`) REFERENCES `df_departments` (`dp_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `urd_user` FOREIGN KEY (`urd_id_user`) REFERENCES `df_users` (`us_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
