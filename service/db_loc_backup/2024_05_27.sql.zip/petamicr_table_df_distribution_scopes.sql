
-- --------------------------------------------------------

--
-- Структура таблицы `df_distribution_scopes`
--

CREATE TABLE `df_distribution_scopes` (
  `dsc_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
