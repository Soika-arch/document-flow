
-- --------------------------------------------------------

--
-- Структура таблицы `df_outgoing_documents_registry`
--

CREATE TABLE `df_outgoing_documents_registry` (
  `odr_id` bigint UNSIGNED NOT NULL,
  `odr_id_user` bigint UNSIGNED NOT NULL COMMENT 'Користувач, який зареєстрував документ',
  `odr_id_document_type` bigint UNSIGNED NOT NULL COMMENT 'Тип документа',
  `odr_id_carrier_type` bigint UNSIGNED NOT NULL COMMENT 'Тип носія документа',
  `odr_id_document_location` bigint UNSIGNED DEFAULT NULL COMMENT 'Фізичне місцезнаходження оригінала',
  `odr_number` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Номер вихідного документа',
  `odr_id_incoming_number` bigint UNSIGNED DEFAULT NULL COMMENT 'Номер відповідного вхідного',
  `odr_registration_form_number` bigint UNSIGNED DEFAULT NULL COMMENT 'Реєстраційний номер бланка',
  `odr_id_title` bigint UNSIGNED NOT NULL COMMENT 'Назва чи заголовок документа',
  `odr_document_date` date DEFAULT NULL COMMENT 'Дата в документі',
  `odr_id_sender` bigint UNSIGNED NOT NULL COMMENT 'Відправник (користувач)',
  `odr_id_recipient` bigint UNSIGNED DEFAULT NULL COMMENT 'Отримувач (зовнішний)',
  `odr_id_description` bigint UNSIGNED DEFAULT NULL COMMENT 'Опис або короткий зміст документа',
  `odr_file_extension` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Розширення файлу завантаженого документа',
  `odr_id_status` bigint UNSIGNED DEFAULT NULL COMMENT 'Статус документа (наприклад, "новий", "в обробці", "завершено")',
  `odr_id_assigned_user` bigint UNSIGNED DEFAULT NULL COMMENT 'Призначений користувач обробки документа.',
  `odr_id_execution_control` bigint UNSIGNED DEFAULT NULL COMMENT 'Контроль виконання: one-time, monthly, quarterly, annually',
  `odr_control_date` datetime DEFAULT NULL COMMENT 'Дата, до якої документ має бути виконаним',
  `odr_execution_date` datetime DEFAULT NULL COMMENT 'Дата виконання документа',
  `odr_add_date` datetime NOT NULL,
  `odr_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Регістр вихідних документів із основними даними';

--
-- Дамп данных таблицы `df_outgoing_documents_registry`
--

INSERT INTO `df_outgoing_documents_registry` (`odr_id`, `odr_id_user`, `odr_id_document_type`, `odr_id_carrier_type`, `odr_id_document_location`, `odr_number`, `odr_id_incoming_number`, `odr_registration_form_number`, `odr_id_title`, `odr_document_date`, `odr_id_sender`, `odr_id_recipient`, `odr_id_description`, `odr_file_extension`, `odr_id_status`, `odr_id_assigned_user`, `odr_id_execution_control`, `odr_control_date`, `odr_execution_date`, `odr_add_date`, `odr_change_date`) VALUES
(1, 1, 1, 1, NULL, '00000002', NULL, 1, 1, '2024-05-27', 50, 1, 1, 'png', 1, NULL, NULL, NULL, NULL, '2024-05-27 13:10:31', '2024-05-27 13:10:31');
