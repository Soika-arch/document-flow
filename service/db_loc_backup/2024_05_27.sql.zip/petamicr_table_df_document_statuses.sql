
-- --------------------------------------------------------

--
-- Структура таблицы `df_document_statuses`
--

CREATE TABLE `df_document_statuses` (
  `dst_id` bigint UNSIGNED NOT NULL,
  `dst_id_user` bigint UNSIGNED NOT NULL COMMENT 'Користовач, який створив статус',
  `dst_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dst_add_date` datetime NOT NULL,
  `dst_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Статуси документів (новий, в обробці ...)';

--
-- Дамп данных таблицы `df_document_statuses`
--

INSERT INTO `df_document_statuses` (`dst_id`, `dst_id_user`, `dst_name`, `dst_add_date`, `dst_change_date`) VALUES
(1, 1, 'Новий', '2024-05-16 11:19:58', '2024-05-16 11:19:58'),
(2, 1, 'В обробці', '2024-05-16 11:20:09', '2024-05-16 11:20:09');
