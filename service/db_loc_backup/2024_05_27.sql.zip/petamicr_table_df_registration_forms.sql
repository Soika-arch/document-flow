
-- --------------------------------------------------------

--
-- Структура таблицы `df_registration_forms`
--

CREATE TABLE `df_registration_forms` (
  `rf_id` bigint UNSIGNED NOT NULL,
  `rf_id_user` bigint UNSIGNED NOT NULL,
  `rf_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rf_add_date` datetime NOT NULL,
  `rf_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Бланки документів';

--
-- Дамп данных таблицы `df_registration_forms`
--

INSERT INTO `df_registration_forms` (`rf_id`, `rf_id_user`, `rf_name`, `rf_add_date`, `rf_change_date`) VALUES
(1, 1, 'Blank 1', '2024-05-22 15:57:02', '2024-05-22 15:57:02'),
(2, 1, 'Blank 2', '2024-05-22 15:57:02', '2024-05-22 15:57:02');
