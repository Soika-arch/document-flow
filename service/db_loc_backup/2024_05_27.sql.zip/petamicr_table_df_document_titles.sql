
-- --------------------------------------------------------

--
-- Структура таблицы `df_document_titles`
--

CREATE TABLE `df_document_titles` (
  `dts_id` bigint UNSIGNED NOT NULL,
  `dts_id_user` bigint UNSIGNED NOT NULL,
  `dts_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `dts_add_date` datetime NOT NULL,
  `dts_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Назви або заголовоки документів';

--
-- Дамп данных таблицы `df_document_titles`
--

INSERT INTO `df_document_titles` (`dts_id`, `dts_id_user`, `dts_title`, `dts_add_date`, `dts_change_date`) VALUES
(1, 1, 'Тестова назва документа', '2024-05-17 14:15:53', '2024-05-17 14:15:53'),
(2, 1, 'Тестова назва документа 2', '2024-05-17 14:15:53', '2024-05-17 14:15:53'),
(3, 1, 'Тестова назва документа 3', '2024-05-17 14:15:53', '2024-05-17 14:15:53');
