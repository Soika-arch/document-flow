
-- --------------------------------------------------------

--
-- Структура таблицы `df_user_rel_departament`
--

CREATE TABLE `df_user_rel_departament` (
  `urd_id` bigint UNSIGNED NOT NULL,
  `urd_id_user` bigint UNSIGNED NOT NULL,
  `urd_id_departament` bigint UNSIGNED NOT NULL,
  `urd_add_date` datetime NOT NULL,
  `urd_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Зв''язки користувачів з департаментами';
