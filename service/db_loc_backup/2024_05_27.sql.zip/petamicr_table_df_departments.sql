
-- --------------------------------------------------------

--
-- Структура таблицы `df_departments`
--

CREATE TABLE `df_departments` (
  `dp_id` bigint UNSIGNED NOT NULL,
  `dp_id_user` bigint UNSIGNED NOT NULL,
  `dp_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Назва відділу',
  `dp_add_date` datetime NOT NULL,
  `dp_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Відділи організації';

--
-- Дамп данных таблицы `df_departments`
--

INSERT INTO `df_departments` (`dp_id`, `dp_id_user`, `dp_name`, `dp_add_date`, `dp_change_date`) VALUES
(1, 1, 'Відділ управління персоналом', '2024-05-16 11:48:18', '2024-05-16 11:48:18'),
(2, 1, 'Фінансовий відділ', '2024-05-16 11:50:30', '2024-05-16 11:50:30'),
(3, 1, 'Відділ інформаційних технологій', '2024-05-16 11:50:30', '2024-05-16 11:50:30');
