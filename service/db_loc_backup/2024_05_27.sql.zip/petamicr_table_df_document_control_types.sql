
-- --------------------------------------------------------

--
-- Структура таблицы `df_document_control_types`
--

CREATE TABLE `df_document_control_types` (
  `dct_id` bigint UNSIGNED NOT NULL,
  `dct_id_user` bigint UNSIGNED NOT NULL,
  `dct_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dct_add_date` datetime NOT NULL,
  `dct_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Видів контролю за виконанням документів';

--
-- Дамп данных таблицы `df_document_control_types`
--

INSERT INTO `df_document_control_types` (`dct_id`, `dct_id_user`, `dct_name`, `dct_add_date`, `dct_change_date`) VALUES
(1, 1, 'Разово', '2024-05-16 13:29:21', '2024-05-16 13:29:21'),
(2, 1, 'Щодня', '2024-05-16 13:29:21', '2024-05-16 13:29:21'),
(3, 1, 'Щотижня', '2024-05-16 13:29:57', '2024-05-16 13:29:57'),
(4, 1, 'Щомісяця', '2024-05-16 13:29:57', '2024-05-16 13:29:57'),
(7, 1, 'Щорічно', '2024-05-16 13:29:57', '2024-05-16 13:29:57');
