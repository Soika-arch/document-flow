
-- --------------------------------------------------------

--
-- Структура таблицы `df_internal_documents_registry`
--

CREATE TABLE `df_internal_documents_registry` (
  `inr_id` bigint UNSIGNED NOT NULL,
  `inr_id_user` int NOT NULL COMMENT 'Користувач, який зареєстрував документ',
  `inr_id_carrier_type` bigint UNSIGNED NOT NULL COMMENT 'Тип носія документа',
  `inr_id_document_location` bigint UNSIGNED DEFAULT NULL COMMENT 'Фізичне місцезнаходження оригінала',
  `inr_number` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Номер документа',
  `inr_additional_number` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Додатковий номер',
  `inr_id_document_type` bigint NOT NULL COMMENT 'Тип документа',
  `inr_id_title` bigint UNSIGNED NOT NULL COMMENT 'Назва чи заголовок документа',
  `inr_document_date` datetime DEFAULT NULL COMMENT 'Дата в документі',
  `inr_id_initiator` bigint UNSIGNED NOT NULL COMMENT 'Ініціатор (користувач)',
  `inr_id_recipient` bigint UNSIGNED DEFAULT NULL COMMENT 'Отримувач (користувач)',
  `inr_id_description` bigint UNSIGNED DEFAULT NULL COMMENT 'Опис або короткий зміст документа',
  `inr_file_extension` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Розширення файлу завантаженого документа',
  `inr_id_status` bigint UNSIGNED DEFAULT NULL COMMENT 'Статус документа (наприклад, "новий", "в обробці", "завершено")',
  `inr_id_responsible_user` bigint UNSIGNED DEFAULT NULL COMMENT 'id відповідального за виконання',
  `inr_id_assigned_departament` bigint UNSIGNED DEFAULT NULL COMMENT 'id відділа, якому призначено на виконання',
  `inr_id_assigned_user` bigint UNSIGNED DEFAULT NULL COMMENT 'Призначений користувач обробки документа.',
  `inr_date_of_receipt_by_executor` bigint UNSIGNED DEFAULT NULL COMMENT 'Дата надходження виконавцю',
  `inr_id_execution_control` bigint UNSIGNED DEFAULT NULL COMMENT 'Контроль виконання: one-time, monthly, quarterly, annually',
  `inr_id_term_of_execution` bigint UNSIGNED DEFAULT NULL COMMENT 'Термін виконання в днях',
  `inr_control_date` datetime DEFAULT NULL COMMENT 'Дата, до якої документ має бути виконаним',
  `inr_execution_date` datetime DEFAULT NULL COMMENT 'Дата виконання документа',
  `inr_distribution_scope` bigint UNSIGNED DEFAULT NULL COMMENT 'Поширюється на',
  `inr_add_date` datetime NOT NULL,
  `inr_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Регістр вихідних документів із основними даними';
