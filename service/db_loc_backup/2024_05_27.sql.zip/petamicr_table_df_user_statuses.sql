
-- --------------------------------------------------------

--
-- Структура таблицы `df_user_statuses`
--

CREATE TABLE `df_user_statuses` (
  `uss_id` bigint UNSIGNED NOT NULL,
  `uss_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `uss_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `uss_access_level` tinyint NOT NULL COMMENT 'Числовий рівень доступу',
  `uss_add_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Статуси користувачів модуля df_';

--
-- Дамп данных таблицы `df_user_statuses`
--

INSERT INTO `df_user_statuses` (`uss_id`, `uss_name`, `uss_description`, `uss_access_level`, `uss_add_date`) VALUES
(1, 'SuperAdmin', 'Супер адміністратор', 1, '2024-05-04 14:45:11'),
(2, 'Admin', 'Адміністратор', 2, '2024-04-24 19:29:50'),
(3, 'User', 'Користувач', 3, '2024-05-04 14:42:53'),
(4, 'Viewer', 'Переглядач', 4, '2024-05-04 14:44:17'),
(5, 'Guest', 'Гість', 5, '2024-04-24 19:32:08');
