
-- --------------------------------------------------------

--
-- Структура таблицы `df_visitor_routes`
--

CREATE TABLE `df_visitor_routes` (
  `vr_id` int UNSIGNED NOT NULL,
  `vr_id_user` bigint UNSIGNED NOT NULL,
  `vr_ip` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `vr_uri` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `vr_user_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vr_queries_count` int UNSIGNED DEFAULT NULL COMMENT 'Количество запросов к БД. при посещении URI.',
  `vr_execution_time` float UNSIGNED NOT NULL COMMENT 'Час повного виконання URL запиту користувача в секундах з точністю до міліонних',
  `vr_add_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
