
-- --------------------------------------------------------

--
-- Структура таблицы `df_document_carrier_types`
--

CREATE TABLE `df_document_carrier_types` (
  `cts_id` bigint UNSIGNED NOT NULL,
  `cts_id_user` bigint UNSIGNED NOT NULL,
  `cts_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cts_add_date` datetime NOT NULL,
  `cts_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Можливі типи носіів документів';

--
-- Дамп данных таблицы `df_document_carrier_types`
--

INSERT INTO `df_document_carrier_types` (`cts_id`, `cts_id_user`, `cts_name`, `cts_add_date`, `cts_change_date`) VALUES
(1, 1, 'Електронний носій', '2024-05-16 10:39:58', '2024-05-16 10:39:58'),
(2, 1, 'Паперовий носій', '2024-05-16 10:39:58', '2024-05-16 10:39:58'),
(3, 1, 'Мікрофільм', '2024-05-16 10:39:58', '2024-05-16 10:39:58');
