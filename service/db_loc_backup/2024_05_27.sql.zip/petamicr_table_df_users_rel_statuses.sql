
-- --------------------------------------------------------

--
-- Структура таблицы `df_users_rel_statuses`
--

CREATE TABLE `df_users_rel_statuses` (
  `usr_id` bigint UNSIGNED NOT NULL,
  `usr_id_user` bigint UNSIGNED NOT NULL,
  `usr_id_status` bigint UNSIGNED NOT NULL,
  `usr_add_date` datetime NOT NULL,
  `usr_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Зв''язки користувачів з їх статусами';

--
-- Дамп данных таблицы `df_users_rel_statuses`
--

INSERT INTO `df_users_rel_statuses` (`usr_id`, `usr_id_user`, `usr_id_status`, `usr_add_date`, `usr_change_date`) VALUES
(1, 1, 1, '2024-04-24 19:30:41', '2024-04-24 19:30:41'),
(2, 0, 5, '2024-04-24 19:32:45', '2024-04-24 19:32:45'),
(29, 50, 3, '2024-05-19 14:21:00', '2024-05-19 14:21:00'),
(30, 51, 4, '2024-05-19 14:26:18', '2024-05-19 14:26:18'),
(35, 47, 3, '2024-05-24 21:51:24', '2024-05-24 21:51:24');
