
-- --------------------------------------------------------

--
-- Структура таблицы `df_terms_of_execution`
--

CREATE TABLE `df_terms_of_execution` (
  `toe_id` bigint UNSIGNED NOT NULL,
  `toe_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `toe_days` tinyint NOT NULL,
  `toe_add_date` datetime NOT NULL,
  `toe_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Терміни виконання для різних типів за контролем виконання';

--
-- Дамп данных таблицы `df_terms_of_execution`
--

INSERT INTO `df_terms_of_execution` (`toe_id`, `toe_name`, `toe_days`, `toe_add_date`, `toe_change_date`) VALUES
(1, 'Стандартний', 10, '2024-05-19 13:25:17', '2024-05-19 13:25:17'),
(2, 'Терміновий', 3, '2024-05-19 13:25:17', '2024-05-19 13:25:17');
