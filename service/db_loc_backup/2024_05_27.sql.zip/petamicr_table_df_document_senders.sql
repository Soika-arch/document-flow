
-- --------------------------------------------------------

--
-- Структура таблицы `df_document_senders`
--

CREATE TABLE `df_document_senders` (
  `dss_id` bigint UNSIGNED NOT NULL,
  `dss_id_user` bigint UNSIGNED DEFAULT NULL,
  `dss_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Назва організації / ФІО',
  `dss_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dss_phone` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dss_address` text COLLATE utf8mb4_unicode_ci,
  `dss_legal_address` text COLLATE utf8mb4_unicode_ci COMMENT 'Юридична адреса',
  `dss_add_date` datetime NOT NULL,
  `dss_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Дані відправників документів';

--
-- Дамп данных таблицы `df_document_senders`
--

INSERT INTO `df_document_senders` (`dss_id`, `dss_id_user`, `dss_name`, `dss_email`, `dss_phone`, `dss_address`, `dss_legal_address`, `dss_add_date`, `dss_change_date`) VALUES
(1, 1, 'Test', 'test@email.com', '0999999999', 'sfasf sfasf', 'sfsdf scdsfsdg', '2024-05-17 13:06:39', '2024-05-17 13:06:39');
