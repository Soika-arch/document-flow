
-- --------------------------------------------------------

--
-- Структура таблицы `df_document_descriptions`
--

CREATE TABLE `df_document_descriptions` (
  `dds_id` bigint UNSIGNED NOT NULL,
  `dds_id_user` bigint NOT NULL,
  `dds_description` text COLLATE utf8mb4_unicode_ci,
  `dds_add_date` datetime NOT NULL,
  `dds_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Опис або короткий зміст документів';

--
-- Дамп данных таблицы `df_document_descriptions`
--

INSERT INTO `df_document_descriptions` (`dds_id`, `dds_id_user`, `dds_description`, `dds_add_date`, `dds_change_date`) VALUES
(1, 1, 'Тестовий короткий зміст документа', '2024-05-17 14:19:29', '2024-05-17 14:19:29');
