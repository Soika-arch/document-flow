
-- --------------------------------------------------------

--
-- Структура таблицы `df_document_locations`
--

CREATE TABLE `df_document_locations` (
  `dlc_id` bigint UNSIGNED NOT NULL,
  `dlc_id_user` bigint UNSIGNED NOT NULL,
  `dlc_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dlc_add_date` datetime NOT NULL,
  `dlc_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Назви місцезнаходжень оригіналів документів';
