
-- --------------------------------------------------------

--
-- Структура таблицы `df_users`
--

CREATE TABLE `df_users` (
  `us_id` bigint UNSIGNED NOT NULL,
  `us_login` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `us_password_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `us_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `us_change_date` datetime DEFAULT NULL,
  `us_add_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `df_users`
--

INSERT INTO `df_users` (`us_id`, `us_login`, `us_password_hash`, `us_email`, `us_change_date`, `us_add_date`) VALUES
(0, 'Guest', '', '', '2024-05-01 20:17:18', '2024-04-14 16:05:13'),
(1, 'Admin', '$2y$10$vEIigCI0EotxwtiXyhE8V.fTo6CgjQhhK78zPWlYwm8XV17WTdkYu', 'test@gmail.com', '2024-05-23 20:17:26', '2024-04-14 16:05:13'),
(47, 'Dvemerixs', '$2y$10$6BTC4Yv/oQU38ZXnP3h1UexK0QiDN10ERNds44dMRVhpvkLddDwlu', 'test2@gmail.com', '2024-05-24 21:51:24', '2024-05-13 16:13:37'),
(50, 'Dvemerix_user', '$2y$10$NujZEa58r1.eCEYNwbY4f.7eqhXR61pfLRkSIoclL8MRgAd5UjYki', 'test1@gmail.com', '2024-05-23 20:17:33', '2024-05-19 14:21:00'),
(51, 'Dvemerix_viewer', '$2y$10$lMtdtFye.IsvStLAJ8yhDOCin2uocWWRW0/vzjjJxyx6TqQ9eNPPy', 'test3@gmail.com', '2024-05-23 20:17:35', '2024-05-19 14:26:18');
