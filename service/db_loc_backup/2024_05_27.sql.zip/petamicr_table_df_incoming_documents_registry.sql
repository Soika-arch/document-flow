
-- --------------------------------------------------------

--
-- Структура таблицы `df_incoming_documents_registry`
--

CREATE TABLE `df_incoming_documents_registry` (
  `idr_id` bigint UNSIGNED NOT NULL,
  `idr_id_user` bigint UNSIGNED NOT NULL COMMENT 'Користувач, який зареєстрував документ',
  `idr_id_document_type` bigint UNSIGNED NOT NULL COMMENT 'Тип документа',
  `idr_id_carrier_type` bigint UNSIGNED NOT NULL COMMENT 'Тип носія документа',
  `idr_id_document_location` bigint UNSIGNED DEFAULT NULL COMMENT 'Відділ фізичного місцезнаходження оригінала',
  `idr_number` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Номер вхідного документа',
  `idr_id_outgoing_number` bigint UNSIGNED DEFAULT NULL COMMENT 'Номер відповідного вихідного',
  `idr_id_title` bigint UNSIGNED NOT NULL COMMENT 'Назва чи заголовок документа',
  `idr_document_date` date DEFAULT NULL COMMENT 'Дата в документі',
  `idr_id_recipient` bigint UNSIGNED DEFAULT NULL COMMENT 'Отримувач (користувач)',
  `idr_id_sender` bigint UNSIGNED DEFAULT NULL COMMENT 'Відправник документу (зовнішній)',
  `idr_id_description` bigint UNSIGNED DEFAULT NULL COMMENT 'Опис або короткий зміст документа',
  `idr_file_extension` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Розширення файлу завантаженого документа',
  `idr_id_status` bigint UNSIGNED DEFAULT NULL COMMENT 'Статус документа (наприклад, "новий", "в обробці", "завершено")',
  `idr_id_responsible_user` bigint UNSIGNED DEFAULT NULL COMMENT 'id відповідального за виконання',
  `idr_id_assigned_user` bigint UNSIGNED DEFAULT NULL COMMENT 'Призначений користувач обробки документа.',
  `idr_id_assigned_departament` bigint UNSIGNED DEFAULT NULL COMMENT 'id відділа, якому призначено на виконання',
  `idr_id_resolution` bigint UNSIGNED DEFAULT NULL COMMENT 'Резолюція',
  `idr_resolution_date` datetime DEFAULT NULL COMMENT 'Дата призначення резолюції',
  `idr_date_of_receipt_by_executor` datetime DEFAULT NULL COMMENT 'Дата надходження виконавцю',
  `idr_id_execution_control` bigint UNSIGNED DEFAULT NULL COMMENT 'Контроль виконання: one-time, monthly, quarterly, annually',
  `idr_id_term_of_execution` bigint UNSIGNED DEFAULT NULL COMMENT 'Термін виконання в днях',
  `idr_control_date` datetime DEFAULT NULL COMMENT 'Дата, до якої документ має бути виконаним',
  `idr_execution_date` datetime DEFAULT NULL COMMENT 'Дата виконання документа',
  `idr_add_date` datetime NOT NULL,
  `idr_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Регістр вхідних документів із основними даними';

--
-- Дамп данных таблицы `df_incoming_documents_registry`
--

INSERT INTO `df_incoming_documents_registry` (`idr_id`, `idr_id_user`, `idr_id_document_type`, `idr_id_carrier_type`, `idr_id_document_location`, `idr_number`, `idr_id_outgoing_number`, `idr_id_title`, `idr_document_date`, `idr_id_recipient`, `idr_id_sender`, `idr_id_description`, `idr_file_extension`, `idr_id_status`, `idr_id_responsible_user`, `idr_id_assigned_user`, `idr_id_assigned_departament`, `idr_id_resolution`, `idr_resolution_date`, `idr_date_of_receipt_by_executor`, `idr_id_execution_control`, `idr_id_term_of_execution`, `idr_control_date`, `idr_execution_date`, `idr_add_date`, `idr_change_date`) VALUES
(1, 1, 1, 1, 1, '00000001', NULL, 1, '2024-05-24', 1, 1, 1, 'png', 1, 1, 50, NULL, 1, NULL, '2024-05-27 00:00:00', 1, 1, NULL, NULL, '2024-05-25 00:00:00', '2024-05-27 18:40:02'),
(2, 50, 1, 1, NULL, '00000002', NULL, 3, '2024-05-27', 50, 1, 1, 'torrent', 1, 50, 47, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-05-27 14:14:54', '2024-05-27 14:50:26'),
(3, 1, 4, 1, 3, '00000003', NULL, 2, '2021-05-27', 51, 1, 1, 'jpg', 1, 50, NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-05-27 16:44:46', '2024-05-27 16:44:46'),
(4, 1, 1, 2, 2, '00000004', NULL, 3, '2022-11-13', 47, 1, 1, 'png', 2, 47, 1, 2, 2, NULL, NULL, 7, 1, NULL, NULL, '2024-05-27 16:50:41', '2024-05-27 16:50:41'),
(5, 1, 1, 1, NULL, '00000005', NULL, 1, '2024-05-27', 51, 1, 1, 'png', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-05-27 17:23:08', '2024-05-27 17:23:08'),
(6, 1, 9, 1, 1, '00000006', NULL, 3, '2024-05-27', 47, 1, 1, 'png', 1, NULL, 47, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-05-27 00:00:00', '2024-05-27 18:44:33');
