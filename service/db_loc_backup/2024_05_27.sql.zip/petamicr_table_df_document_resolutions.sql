
-- --------------------------------------------------------

--
-- Структура таблицы `df_document_resolutions`
--

CREATE TABLE `df_document_resolutions` (
  `drs_id` bigint UNSIGNED NOT NULL,
  `drs_id_user` bigint UNSIGNED NOT NULL,
  `drs_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `drs_add_date` datetime NOT NULL,
  `drs_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Резолюції документів';

--
-- Дамп данных таблицы `df_document_resolutions`
--

INSERT INTO `df_document_resolutions` (`drs_id`, `drs_id_user`, `drs_content`, `drs_add_date`, `drs_change_date`) VALUES
(1, 1, 'До виконання', '2024-05-16 12:25:57', '2024-05-16 12:25:57'),
(2, 1, 'На контроль', '2024-05-16 12:25:57', '2024-05-16 12:25:57'),
(3, 1, 'До відома', '2024-05-16 12:27:17', '2024-05-16 12:27:17'),
(4, 1, 'На узгодження', '2024-05-16 12:27:17', '2024-05-16 12:27:17');
