-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Май 23 2024 г., 16:48
-- Версия сервера: 8.0.36-0ubuntu0.22.04.1
-- Версия PHP: 8.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `petamicr`
--

-- --------------------------------------------------------

--
-- Структура таблицы `df_departments`
--

CREATE TABLE `df_departments` (
  `dp_id` bigint UNSIGNED NOT NULL,
  `dp_id_user` bigint UNSIGNED NOT NULL,
  `dp_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Назва відділу',
  `dp_add_date` datetime NOT NULL,
  `dp_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Відділи організації';

--
-- Дамп данных таблицы `df_departments`
--

INSERT INTO `df_departments` (`dp_id`, `dp_id_user`, `dp_name`, `dp_add_date`, `dp_change_date`) VALUES
(1, 1, 'Відділ управління персоналом', '2024-05-16 11:48:18', '2024-05-16 11:48:18'),
(2, 1, 'Фінансовий відділ', '2024-05-16 11:50:30', '2024-05-16 11:50:30'),
(3, 1, 'Відділ інформаційних технологій', '2024-05-16 11:50:30', '2024-05-16 11:50:30');

-- --------------------------------------------------------

--
-- Структура таблицы `df_distribution_scopes`
--

CREATE TABLE `df_distribution_scopes` (
  `dsc_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `df_document_carrier_types`
--

CREATE TABLE `df_document_carrier_types` (
  `cts_id` bigint UNSIGNED NOT NULL,
  `cts_id_user` bigint UNSIGNED NOT NULL,
  `cts_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cts_add_date` datetime NOT NULL,
  `cts_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Можливі типи носіів документів';

--
-- Дамп данных таблицы `df_document_carrier_types`
--

INSERT INTO `df_document_carrier_types` (`cts_id`, `cts_id_user`, `cts_name`, `cts_add_date`, `cts_change_date`) VALUES
(1, 1, 'Електронний носій', '2024-05-16 10:39:58', '2024-05-16 10:39:58'),
(2, 1, 'Паперовий носій', '2024-05-16 10:39:58', '2024-05-16 10:39:58'),
(3, 1, 'Мікрофільм', '2024-05-16 10:39:58', '2024-05-16 10:39:58');

-- --------------------------------------------------------

--
-- Структура таблицы `df_document_control_types`
--

CREATE TABLE `df_document_control_types` (
  `dct_id` bigint UNSIGNED NOT NULL,
  `dct_id_user` bigint UNSIGNED NOT NULL,
  `dct_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dct_add_date` datetime NOT NULL,
  `dct_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Видів контролю за виконанням документів';

--
-- Дамп данных таблицы `df_document_control_types`
--

INSERT INTO `df_document_control_types` (`dct_id`, `dct_id_user`, `dct_name`, `dct_add_date`, `dct_change_date`) VALUES
(1, 1, 'Разово', '2024-05-16 13:29:21', '2024-05-16 13:29:21'),
(2, 1, 'Щодня', '2024-05-16 13:29:21', '2024-05-16 13:29:21'),
(3, 1, 'Щотижня', '2024-05-16 13:29:57', '2024-05-16 13:29:57'),
(4, 1, 'Щомісяця', '2024-05-16 13:29:57', '2024-05-16 13:29:57'),
(7, 1, 'Щорічно', '2024-05-16 13:29:57', '2024-05-16 13:29:57');

-- --------------------------------------------------------

--
-- Структура таблицы `df_document_descriptions`
--

CREATE TABLE `df_document_descriptions` (
  `dds_id` bigint UNSIGNED NOT NULL,
  `dds_id_user` bigint NOT NULL,
  `dds_description` text COLLATE utf8mb4_unicode_ci,
  `dds_add_date` datetime NOT NULL,
  `dds_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Опис або короткий зміст документів';

--
-- Дамп данных таблицы `df_document_descriptions`
--

INSERT INTO `df_document_descriptions` (`dds_id`, `dds_id_user`, `dds_description`, `dds_add_date`, `dds_change_date`) VALUES
(1, 1, 'Тестовий короткий зміст документа', '2024-05-17 14:19:29', '2024-05-17 14:19:29');

-- --------------------------------------------------------

--
-- Структура таблицы `df_document_locations`
--

CREATE TABLE `df_document_locations` (
  `dlc_id` bigint UNSIGNED NOT NULL,
  `dlc_id_user` bigint UNSIGNED NOT NULL,
  `dlc_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dlc_add_date` datetime NOT NULL,
  `dlc_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Назви місцезнаходжень оригіналів документів';

-- --------------------------------------------------------

--
-- Структура таблицы `df_document_resolutions`
--

CREATE TABLE `df_document_resolutions` (
  `drs_id` bigint UNSIGNED NOT NULL,
  `drs_id_user` bigint UNSIGNED NOT NULL,
  `drs_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `drs_add_date` datetime NOT NULL,
  `drs_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Резолюції документів';

--
-- Дамп данных таблицы `df_document_resolutions`
--

INSERT INTO `df_document_resolutions` (`drs_id`, `drs_id_user`, `drs_content`, `drs_add_date`, `drs_change_date`) VALUES
(1, 1, 'До виконання', '2024-05-16 12:25:57', '2024-05-16 12:25:57'),
(2, 1, 'На контроль', '2024-05-16 12:25:57', '2024-05-16 12:25:57'),
(3, 1, 'До відома', '2024-05-16 12:27:17', '2024-05-16 12:27:17'),
(4, 1, 'На узгодження', '2024-05-16 12:27:17', '2024-05-16 12:27:17');

-- --------------------------------------------------------

--
-- Структура таблицы `df_document_senders`
--

CREATE TABLE `df_document_senders` (
  `dss_id` bigint UNSIGNED NOT NULL,
  `dss_id_user` bigint UNSIGNED DEFAULT NULL,
  `dss_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Назва організації / ФІО',
  `dss_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dss_phone` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dss_address` text COLLATE utf8mb4_unicode_ci,
  `dss_legal_address` text COLLATE utf8mb4_unicode_ci COMMENT 'Юридична адреса',
  `dss_add_date` datetime NOT NULL,
  `dss_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Дані відправників документів';

--
-- Дамп данных таблицы `df_document_senders`
--

INSERT INTO `df_document_senders` (`dss_id`, `dss_id_user`, `dss_name`, `dss_email`, `dss_phone`, `dss_address`, `dss_legal_address`, `dss_add_date`, `dss_change_date`) VALUES
(1, 1, 'Test', 'test@email.com', '0999999999', 'sfasf sfasf', 'sfsdf scdsfsdg', '2024-05-17 13:06:39', '2024-05-17 13:06:39');

-- --------------------------------------------------------

--
-- Структура таблицы `df_document_statuses`
--

CREATE TABLE `df_document_statuses` (
  `dst_id` bigint UNSIGNED NOT NULL,
  `dst_id_user` bigint UNSIGNED NOT NULL COMMENT 'Користовач, який створив статус',
  `dst_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dst_add_date` datetime NOT NULL,
  `dst_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Статуси документів (новий, в обробці ...)';

--
-- Дамп данных таблицы `df_document_statuses`
--

INSERT INTO `df_document_statuses` (`dst_id`, `dst_id_user`, `dst_name`, `dst_add_date`, `dst_change_date`) VALUES
(1, 1, 'Новий', '2024-05-16 11:19:58', '2024-05-16 11:19:58'),
(2, 1, 'В обробці', '2024-05-16 11:20:09', '2024-05-16 11:20:09');

-- --------------------------------------------------------

--
-- Структура таблицы `df_document_titles`
--

CREATE TABLE `df_document_titles` (
  `dts_id` bigint UNSIGNED NOT NULL,
  `dts_id_user` bigint UNSIGNED NOT NULL,
  `dts_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `dts_add_date` datetime NOT NULL,
  `dts_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Назви або заголовоки документів';

--
-- Дамп данных таблицы `df_document_titles`
--

INSERT INTO `df_document_titles` (`dts_id`, `dts_id_user`, `dts_title`, `dts_add_date`, `dts_change_date`) VALUES
(1, 1, 'Тестова назва документа', '2024-05-17 14:15:53', '2024-05-17 14:15:53'),
(2, 1, 'Тестова назва документа 2', '2024-05-17 14:15:53', '2024-05-17 14:15:53'),
(3, 1, 'Тестова назва документа 3', '2024-05-17 14:15:53', '2024-05-17 14:15:53');

-- --------------------------------------------------------

--
-- Структура таблицы `df_document_types`
--

CREATE TABLE `df_document_types` (
  `dt_id` bigint UNSIGNED NOT NULL,
  `dt_id_user` bigint NOT NULL,
  `dt_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dt_description` text COLLATE utf8mb4_unicode_ci,
  `dt_add_date` datetime NOT NULL,
  `dt_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Типи документів';

--
-- Дамп данных таблицы `df_document_types`
--

INSERT INTO `df_document_types` (`dt_id`, `dt_id_user`, `dt_name`, `dt_description`, `dt_add_date`, `dt_change_date`) VALUES
(1, 1, 'Лист', 'Документ у формі листа', '2024-05-04 14:28:44', '2024-05-04 14:28:44'),
(2, 1, 'Службова записка', 'Документ у формі записки', '2024-05-04 14:30:36', '2024-05-04 14:30:36'),
(3, 1, 'Заява', 'Заява або запит', '2024-05-04 14:31:10', '2024-05-04 14:31:10'),
(4, 1, 'Протокол', 'Протокол наради', '2024-05-04 14:31:32', '2024-05-04 14:31:32'),
(8, 1, 'Уведомительное сообщение', 'Це тип документа, який використовується для передачі інформації або сповіщення всередині організації чи підприємства. Воно може містити важливі оголошення, повідомлення про події, інформацію про зміни в процесах або правилах, запрошення на заходи тощо. д. Повідомлення зазвичай мають короткий формат і спрямовані на оперативне інформування співробітників або зацікавлених сторін про важливі події або обставини.', '2024-05-15 20:35:02', '2024-05-15 20:35:02'),
(9, 1, 'Наказ про призначення посаду', 'Цей наказ видається керівництвом підприємства для офіційного призначення співробітника певну посаду всередині організації. У наказі вказується ПІБ співробітника, його нова посада, дата початку роботи на новій посаді, а також інші відповідні деталі, такі як відділ або підрозділ, до якого він належить. Такий наказ є офіційним повідомленням про зміну посади та статусу співробітника в організації', '2024-05-15 20:37:42', '2024-05-15 20:37:42'),
(10, 1, 'Наказ про проведення інструктажу з охорони праці', 'Цей наказ видається керівництвом підприємства щодо обов&#039;язкового інструктажу з питань охорони праці серед співробітників. У наказі зазначається дата та час проведення інструктажу, а також відповідні вимоги та інструкції, які мають бути подані під час інструктажу. Такий наказ спрямований на забезпечення безпеки та здоров&#039;я працівників на робочому місці шляхом надання їм необхідної інформації та інструктажу щодо правил та процедур з охорони праці.', '2024-05-15 20:38:54', '2024-05-15 20:38:54'),
(11, 1, 'Наказ про преміювання працівника', 'Цей наказ видається керівництвом підприємства для офіційного повідомлення співробітника про намір преміювати його за досягнення, визначні результати роботи, виконання поставленої мети або інші заслуги. У наказі вказується сума премії, підстава для її призначення, а також дата та порядок виплати. Такий наказ служить для заохочення співробітників за їхню хорошу роботу та мотивації до досягнення кращих результатів', '2024-05-15 20:41:13', '2024-05-15 20:41:13'),
(12, 1, 'Вхідний лист від контрагента', 'Це вхідний документ, отриманий вашим підприємством від зовнішнього контрагента чи партнера. Зазвичай такі листи містять інформацію про пропозиції, запити, замовлення, рекламні матеріали, юридичні документи або будь-яку іншу важливу інформацію щодо взаємодії з контрагентом. Вхідні листи можуть бути направлені на обговорення подальших дій, відповіді на запитання, запити на надання додаткової інформації чи інші заходи', '2024-05-15 20:43:01', '2024-05-15 20:43:01'),
(13, 1, 'Вхідний акт приймання-передачі товарів', 'Це вхідний документ, отриманий вашим підприємством від постачальника товарів чи послуг. У такому акті зазвичай фіксуються деталі про поставлені товари чи послуги, їх кількість, якість, вартість та інші суттєві характеристики. Цей документ є підставою для приймання товарів чи послуг і може використовуватися для перевірки відповідності поставлених матеріалів чи послуг умовам контракту чи замовлення', '2024-05-15 20:44:17', '2024-05-15 20:44:17'),
(14, 1, 'Вхідний звіт про виконані роботи від підрозділу', 'Це документ, отриманий вашим підприємством від одного з підрозділів організації. Звіт про виконані роботи зазвичай містить інформацію про виконану роботу, досягнуті результати, витрачені ресурси (час, матеріали, працю) та інші істотні деталі виконаних завдань. Такі звіти можуть бути використані для оцінки ефективності роботи підрозділів, складання загальних звітів про діяльність підприємства, а також для прийняття управлінських рішень', '2024-05-15 20:45:18', '2024-05-15 20:45:18');

-- --------------------------------------------------------

--
-- Структура таблицы `df_incoming_documents_registry`
--

CREATE TABLE `df_incoming_documents_registry` (
  `idr_id` bigint UNSIGNED NOT NULL,
  `idr_id_user` bigint UNSIGNED NOT NULL COMMENT 'Користувач, який зареєстрував документ',
  `idr_id_document_type` bigint UNSIGNED NOT NULL COMMENT 'Тип документа',
  `idr_id_carrier_type` bigint UNSIGNED NOT NULL COMMENT 'Тип носія документа',
  `idr_id_document_location` bigint UNSIGNED DEFAULT NULL COMMENT 'Відділ фізичного місцезнаходження оригінала',
  `idr_number` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Номер вхідного документа',
  `idr_id_outgoing_number` bigint UNSIGNED DEFAULT NULL COMMENT 'Номер вихідного',
  `idr_id_title` bigint UNSIGNED NOT NULL COMMENT 'Назва чи заголовок документа',
  `idr_document_date` date DEFAULT NULL COMMENT 'Дата в документі',
  `idr_id_recipient` bigint UNSIGNED DEFAULT NULL COMMENT 'Отримувач (користувач)',
  `idr_id_sender` bigint UNSIGNED DEFAULT NULL COMMENT 'Відправник документу (зовнішній)',
  `idr_id_description` bigint UNSIGNED DEFAULT NULL COMMENT 'Опис або короткий зміст документа',
  `idr_file_extension` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Розширення файлу завантаженого документа',
  `idr_id_status` bigint UNSIGNED DEFAULT NULL COMMENT 'Статус документа (наприклад, "новий", "в обробці", "завершено")',
  `idr_id_responsible_user` bigint UNSIGNED DEFAULT NULL COMMENT 'id відповідального за виконання',
  `idr_id_assigned_user` bigint UNSIGNED DEFAULT NULL COMMENT 'Призначений користувач обробки документа.',
  `idr_id_assigned_departament` bigint UNSIGNED DEFAULT NULL COMMENT 'id відділа, якому призначено на виконання',
  `idr_id_resolution` bigint UNSIGNED DEFAULT NULL COMMENT 'Резолюція',
  `idr_resolution_date` datetime DEFAULT NULL COMMENT 'Дата призначення резолюції',
  `idr_date_of_receipt_by_executor` datetime DEFAULT NULL COMMENT 'Дата надходження виконавцю',
  `idr_id_execution_control` bigint UNSIGNED DEFAULT NULL COMMENT 'Контроль виконання: one-time, monthly, quarterly, annually',
  `idr_id_term_of_execution` bigint UNSIGNED DEFAULT NULL COMMENT 'Термін виконання в днях',
  `idr_control_date` datetime DEFAULT NULL COMMENT 'Дата, до якої документ має бути виконаним',
  `idr_execution_date` datetime DEFAULT NULL COMMENT 'Дата виконання документа',
  `idr_add_date` datetime NOT NULL,
  `idr_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Регістр вхідних документів із основними даними';

--
-- Дамп данных таблицы `df_incoming_documents_registry`
--

INSERT INTO `df_incoming_documents_registry` (`idr_id`, `idr_id_user`, `idr_id_document_type`, `idr_id_carrier_type`, `idr_id_document_location`, `idr_number`, `idr_id_outgoing_number`, `idr_id_title`, `idr_document_date`, `idr_id_recipient`, `idr_id_sender`, `idr_id_description`, `idr_file_extension`, `idr_id_status`, `idr_id_responsible_user`, `idr_id_assigned_user`, `idr_id_assigned_departament`, `idr_id_resolution`, `idr_resolution_date`, `idr_date_of_receipt_by_executor`, `idr_id_execution_control`, `idr_id_term_of_execution`, `idr_control_date`, `idr_execution_date`, `idr_add_date`, `idr_change_date`) VALUES
(1, 1, 1, 1, 1, 'inc_7s1h56', NULL, 1, '2024-05-18', 1, 1, 1, 'jpg', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-05-18 18:56:45', '2024-05-18 18:56:45'),
(2, 1, 12, 1, 3, 'inc_66r74h', NULL, 1, '2024-05-19', 47, 1, 1, 'pdf', 1, 47, 1, 3, 1, NULL, NULL, 2, NULL, '2024-05-31 00:00:00', NULL, '2024-05-19 12:22:30', '2024-05-19 12:22:30'),
(3, 1, 3, 1, 2, 'inc_q39v45', NULL, 2, '2024-05-19', 47, 1, 1, 'pdf', 1, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, NULL, '2024-05-19 12:30:46', '2024-05-19 12:30:46'),
(4, 1, 8, 1, 1, 'inc_5537gy', NULL, 3, '2024-05-19', NULL, 1, 1, 'pdf', 1, NULL, NULL, NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL, '2024-05-19 12:31:37', '2024-05-19 12:31:37'),
(5, 1, 11, 1, 1, 'inc_73r04o', NULL, 1, '2024-05-19', 47, 1, 1, 'jpg', 1, 47, 1, 2, 2, NULL, NULL, 1, NULL, NULL, NULL, '2024-05-19 12:32:53', '2024-05-19 12:32:53'),
(6, 1, 9, 1, 1, 'inc_93v1n0', NULL, 2, '2024-05-19', 47, 1, NULL, 'jpg', 2, 47, NULL, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, '2024-05-19 12:40:03', '2024-05-19 12:40:03'),
(7, 1, 1, 1, 2, 'inc_ox818f', NULL, 3, '2024-05-19', 50, 1, 1, 'pdf', 2, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-05-19 17:26:16', '2024-05-19 17:26:16'),
(8, 1, 1, 1, 2, 'inc_u8mlfy', NULL, 2, '2024-05-19', 51, 1, 1, 'pdf', 1, 50, NULL, NULL, NULL, NULL, NULL, 2, 2, NULL, NULL, '2024-05-19 17:31:22', '2024-05-19 17:31:22'),
(9, 1, 14, 1, 2, 'inc_z7ynk3', NULL, 1, '2024-05-22', 50, 1, 1, 'pdf', 1, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, NULL, '2024-05-22 19:23:54', '2024-05-22 19:23:54'),
(10, 1, 1, 1, NULL, 'inc_5hgi1l', NULL, 2, NULL, 1, 1, 1, 'pdf', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-05-22 19:26:39', '2024-05-22 19:26:39'),
(11, 1, 1, 1, 1, 'inc_2u0k2z', NULL, 2, '2024-05-23', 1, 1, 1, 'jpg', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-05-23 05:06:58', '2024-05-23 05:06:58'),
(12, 1, 1, 1, 2, 'inc_gzxekf', NULL, 2, '2024-05-23', 1, 1, 1, 'png', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-05-23 15:42:18', '2024-05-23 15:42:18'),
(13, 1, 1, 1, 2, 'inc_u1ziqp', NULL, 2, '2024-05-23', 1, 1, 1, 'png', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-05-23 15:44:15', '2024-05-23 15:44:15'),
(14, 1, 1, 1, 2, 'inc_wqky1p', NULL, 2, '2024-05-23', 1, 1, 1, 'png', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-05-23 16:11:37', '2024-05-23 16:11:37');

-- --------------------------------------------------------

--
-- Структура таблицы `df_internal_documents_registry`
--

CREATE TABLE `df_internal_documents_registry` (
  `inr_id` bigint UNSIGNED NOT NULL,
  `inr_id_user` int NOT NULL COMMENT 'Користувач, який зареєстрував документ',
  `inr_id_carrier_type` bigint UNSIGNED NOT NULL COMMENT 'Тип носія документа',
  `inr_id_document_location` bigint UNSIGNED DEFAULT NULL COMMENT 'Фізичне місцезнаходження оригінала',
  `inr_number` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Номер документа',
  `inr_additional_number` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Додатковий номер',
  `inr_id_document_type` bigint NOT NULL COMMENT 'Тип документа',
  `inr_id_title` bigint UNSIGNED NOT NULL COMMENT 'Назва чи заголовок документа',
  `inr_document_date` datetime DEFAULT NULL COMMENT 'Дата в документі',
  `inr_id_initiator` bigint UNSIGNED NOT NULL COMMENT 'Ініціатор (користувач)',
  `inr_id_recipient` bigint UNSIGNED DEFAULT NULL COMMENT 'Отримувач (користувач)',
  `inr_id_description` bigint UNSIGNED DEFAULT NULL COMMENT 'Опис або короткий зміст документа',
  `inr_file_extension` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Розширення файлу завантаженого документа',
  `inr_id_status` bigint UNSIGNED DEFAULT NULL COMMENT 'Статус документа (наприклад, "новий", "в обробці", "завершено")',
  `inr_id_responsible_user` bigint UNSIGNED DEFAULT NULL COMMENT 'id відповідального за виконання',
  `inr_id_assigned_departament` bigint UNSIGNED DEFAULT NULL COMMENT 'id відділа, якому призначено на виконання',
  `inr_id_assigned_user` bigint UNSIGNED DEFAULT NULL COMMENT 'Призначений користувач обробки документа.',
  `inr_date_of_receipt_by_executor` bigint UNSIGNED DEFAULT NULL COMMENT 'Дата надходження виконавцю',
  `inr_id_execution_control` bigint UNSIGNED DEFAULT NULL COMMENT 'Контроль виконання: one-time, monthly, quarterly, annually',
  `inr_id_term_of_execution` bigint UNSIGNED DEFAULT NULL COMMENT 'Термін виконання в днях',
  `inr_control_date` datetime DEFAULT NULL COMMENT 'Дата, до якої документ має бути виконаним',
  `inr_execution_date` datetime DEFAULT NULL COMMENT 'Дата виконання документа',
  `inr_distribution_scope` bigint UNSIGNED DEFAULT NULL COMMENT 'Поширюється на',
  `inr_add_date` datetime NOT NULL,
  `inr_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Регістр вихідних документів із основними даними';

--
-- Дамп данных таблицы `df_internal_documents_registry`
--

INSERT INTO `df_internal_documents_registry` (`inr_id`, `inr_id_user`, `inr_id_carrier_type`, `inr_id_document_location`, `inr_number`, `inr_additional_number`, `inr_id_document_type`, `inr_id_title`, `inr_document_date`, `inr_id_initiator`, `inr_id_recipient`, `inr_id_description`, `inr_file_extension`, `inr_id_status`, `inr_id_responsible_user`, `inr_id_assigned_departament`, `inr_id_assigned_user`, `inr_date_of_receipt_by_executor`, `inr_id_execution_control`, `inr_id_term_of_execution`, `inr_control_date`, `inr_execution_date`, `inr_distribution_scope`, `inr_add_date`, `inr_change_date`) VALUES
(1, 1, 1, 2, 'int_qswhhn', NULL, 14, 2, '2024-05-23 00:00:00', 1, 50, 1, 'jpg', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-05-23 05:13:56', '2024-05-23 05:13:56'),
(2, 1, 1, 1, 'int_e6jbu3', '94ht6r', 9, 2, '2024-05-23 00:00:00', 47, 47, 1, 'jpg', 2, 50, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-05-23 18:45:19', '2024-05-23 18:45:19'),
(3, 1, 1, 1, 'int_dlaniq', '94ht6r', 9, 2, '2024-05-23 00:00:00', 47, 47, 1, 'jpg', 2, 50, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-05-23 18:46:35', '2024-05-23 18:46:35');

-- --------------------------------------------------------

--
-- Структура таблицы `df_outgoing_documents_registry`
--

CREATE TABLE `df_outgoing_documents_registry` (
  `odr_id` bigint UNSIGNED NOT NULL,
  `odr_id_user` bigint UNSIGNED NOT NULL COMMENT 'Користувач, який зареєстрував документ',
  `odr_id_document_type` bigint UNSIGNED NOT NULL COMMENT 'Тип документа',
  `odr_id_carrier_type` bigint UNSIGNED NOT NULL COMMENT 'Тип носія документа',
  `odr_id_document_location` bigint UNSIGNED DEFAULT NULL COMMENT 'Фізичне місцезнаходження оригінала',
  `odr_number` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Номер вихідного документа',
  `odr_id_incoming_number` bigint UNSIGNED DEFAULT NULL COMMENT 'Номер відповідного вхідного',
  `odr_registration_form_number` bigint UNSIGNED DEFAULT NULL COMMENT 'Реєстраційний номер бланка',
  `odr_id_title` bigint UNSIGNED NOT NULL COMMENT 'Назва чи заголовок документа',
  `odr_document_date` date DEFAULT NULL COMMENT 'Дата в документі',
  `odr_id_sender` bigint UNSIGNED NOT NULL COMMENT 'Відправник (користувач)',
  `odr_id_recipient` bigint UNSIGNED DEFAULT NULL COMMENT 'Отримувач (зовнішний)',
  `odr_id_description` bigint UNSIGNED DEFAULT NULL COMMENT 'Опис або короткий зміст документа',
  `odr_file_extension` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Розширення файлу завантаженого документа',
  `odr_id_status` bigint UNSIGNED DEFAULT NULL COMMENT 'Статус документа (наприклад, "новий", "в обробці", "завершено")',
  `odr_id_assigned_user` bigint UNSIGNED DEFAULT NULL COMMENT 'Призначений користувач обробки документа.',
  `odr_id_execution_control` bigint UNSIGNED DEFAULT NULL COMMENT 'Контроль виконання: one-time, monthly, quarterly, annually',
  `odr_control_date` datetime DEFAULT NULL COMMENT 'Дата, до якої документ має бути виконаним',
  `odr_execution_date` datetime DEFAULT NULL COMMENT 'Дата виконання документа',
  `odr_add_date` datetime NOT NULL,
  `odr_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Регістр вихідних документів із основними даними';

--
-- Дамп данных таблицы `df_outgoing_documents_registry`
--

INSERT INTO `df_outgoing_documents_registry` (`odr_id`, `odr_id_user`, `odr_id_document_type`, `odr_id_carrier_type`, `odr_id_document_location`, `odr_number`, `odr_id_incoming_number`, `odr_registration_form_number`, `odr_id_title`, `odr_document_date`, `odr_id_sender`, `odr_id_recipient`, `odr_id_description`, `odr_file_extension`, `odr_id_status`, `odr_id_assigned_user`, `odr_id_execution_control`, `odr_control_date`, `odr_execution_date`, `odr_add_date`, `odr_change_date`) VALUES
(1, 1, 1, 1, NULL, 'out_wpe7vn', NULL, 1, 2, '2024-05-22', 1, 1, 1, 'pdf', 1, NULL, NULL, NULL, NULL, '2024-05-22 19:33:24', '2024-05-22 19:33:24'),
(2, 1, 3, 1, NULL, 'out_022k5q', 1, 2, 2, '2024-05-23', 47, 1, 1, 'jpg', 1, NULL, 2, NULL, NULL, '2024-05-23 02:44:09', '2024-05-23 02:44:09'),
(3, 1, 8, 1, NULL, 'out_tw5uw7', NULL, 1, 2, '2024-05-23', 51, 1, 1, 'png', 1, NULL, NULL, NULL, NULL, '2024-05-23 03:15:53', '2024-05-23 03:15:53'),
(4, 1, 12, 1, NULL, 'out_0m0fgb', NULL, 2, 3, '2024-05-23', 50, 1, 1, 'png', 1, NULL, NULL, NULL, NULL, '2024-05-23 03:16:45', '2024-05-23 03:16:45'),
(5, 1, 1, 1, NULL, 'out_58vw9y', NULL, 1, 3, '2024-05-23', 1, 1, 1, 'png', 1, NULL, 4, NULL, NULL, '2024-05-23 03:17:53', '2024-05-23 03:17:53'),
(6, 1, 4, 1, NULL, 'out_klso1e', NULL, 1, 1, '2024-05-22', 47, 1, 1, 'png', 2, NULL, NULL, NULL, NULL, '2024-05-23 03:18:46', '2024-05-23 03:18:46'),
(7, 1, 4, 2, 1, 'inc_e7ojlp', NULL, 1, 1, '2024-05-23', 50, 1, 1, 'pdf', 1, NULL, 3, NULL, NULL, '2024-05-23 18:43:34', '2024-05-23 18:43:34');

-- --------------------------------------------------------

--
-- Структура таблицы `df_registration_forms`
--

CREATE TABLE `df_registration_forms` (
  `rf_id` bigint UNSIGNED NOT NULL,
  `rf_id_user` bigint UNSIGNED NOT NULL,
  `rf_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rf_add_date` datetime NOT NULL,
  `rf_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Бланки документів';

--
-- Дамп данных таблицы `df_registration_forms`
--

INSERT INTO `df_registration_forms` (`rf_id`, `rf_id_user`, `rf_name`, `rf_add_date`, `rf_change_date`) VALUES
(1, 1, 'Blank 1', '2024-05-22 15:57:02', '2024-05-22 15:57:02'),
(2, 1, 'Blank 2', '2024-05-22 15:57:02', '2024-05-22 15:57:02');

-- --------------------------------------------------------

--
-- Структура таблицы `df_terms_of_execution`
--

CREATE TABLE `df_terms_of_execution` (
  `toe_id` bigint UNSIGNED NOT NULL,
  `toe_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `toe_days` tinyint NOT NULL,
  `toe_add_date` datetime NOT NULL,
  `toe_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Терміни виконання для різних типів за контролем виконання';

--
-- Дамп данных таблицы `df_terms_of_execution`
--

INSERT INTO `df_terms_of_execution` (`toe_id`, `toe_name`, `toe_days`, `toe_add_date`, `toe_change_date`) VALUES
(1, 'Стандартний', 10, '2024-05-19 13:25:17', '2024-05-19 13:25:17'),
(2, 'Терміновий', 3, '2024-05-19 13:25:17', '2024-05-19 13:25:17');

-- --------------------------------------------------------

--
-- Структура таблицы `df_users`
--

CREATE TABLE `df_users` (
  `us_id` bigint UNSIGNED NOT NULL,
  `us_login` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `us_password_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `us_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `us_add_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `df_users`
--

INSERT INTO `df_users` (`us_id`, `us_login`, `us_password_hash`, `us_email`, `us_add_date`) VALUES
(0, 'Guest', '', '', '2024-04-14 16:05:13'),
(1, 'Admin', '$2y$10$vEIigCI0EotxwtiXyhE8V.fTo6CgjQhhK78zPWlYwm8XV17WTdkYu', 'test@gmail.com', '2024-04-14 16:05:13'),
(47, 'Dvemerixs', '$2y$10$6BTC4Yv/oQU38ZXnP3h1UexK0QiDN10ERNds44dMRVhpvkLddDwlu', 'test2@gmail.com', '2024-05-13 16:13:37'),
(50, 'Dvemerix-user', '$2y$10$NujZEa58r1.eCEYNwbY4f.7eqhXR61pfLRkSIoclL8MRgAd5UjYki', 'test1@gmail.com', '2024-05-19 14:21:00'),
(51, 'Dvemerix-viewer', '$2y$10$lMtdtFye.IsvStLAJ8yhDOCin2uocWWRW0/vzjjJxyx6TqQ9eNPPy', 'test3@gmail.com', '2024-05-19 14:26:18');

-- --------------------------------------------------------

--
-- Структура таблицы `df_users_rel_statuses`
--

CREATE TABLE `df_users_rel_statuses` (
  `usr_id` bigint UNSIGNED NOT NULL,
  `usr_id_user` bigint UNSIGNED NOT NULL,
  `usr_id_status` bigint UNSIGNED NOT NULL,
  `usr_add_date` datetime NOT NULL,
  `usr_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Зв''язки користувачів з їх статусами';

--
-- Дамп данных таблицы `df_users_rel_statuses`
--

INSERT INTO `df_users_rel_statuses` (`usr_id`, `usr_id_user`, `usr_id_status`, `usr_add_date`, `usr_change_date`) VALUES
(1, 1, 1, '2024-04-24 19:30:41', '2024-04-24 19:30:41'),
(2, 0, 5, '2024-04-24 19:32:45', '2024-04-24 19:32:45'),
(26, 47, 4, '2024-05-13 16:13:37', '2024-05-13 16:13:37'),
(29, 50, 3, '2024-05-19 14:21:00', '2024-05-19 14:21:00'),
(30, 51, 4, '2024-05-19 14:26:18', '2024-05-19 14:26:18');

-- --------------------------------------------------------

--
-- Структура таблицы `df_user_document_access`
--

CREATE TABLE `df_user_document_access` (
  `uda_id` bigint UNSIGNED NOT NULL,
  `uda_id_user` bigint UNSIGNED NOT NULL COMMENT 'Користувач, який надав доступ',
  `uda_id_recipient` bigint UNSIGNED NOT NULL,
  `uda_id_document` bigint UNSIGNED NOT NULL,
  `uda_add_date` datetime NOT NULL,
  `uda_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Таблиця доступу до документів користувачів';

-- --------------------------------------------------------

--
-- Структура таблицы `df_user_rel_departament`
--

CREATE TABLE `df_user_rel_departament` (
  `urd_id` bigint UNSIGNED NOT NULL,
  `urd_id_user` bigint UNSIGNED NOT NULL,
  `urd_id_departament` bigint UNSIGNED NOT NULL,
  `urd_add_date` datetime NOT NULL,
  `urd_change_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Зв''язки користувачів з департаментами';

-- --------------------------------------------------------

--
-- Структура таблицы `df_user_statuses`
--

CREATE TABLE `df_user_statuses` (
  `uss_id` bigint UNSIGNED NOT NULL,
  `uss_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `uss_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `uss_access_level` tinyint NOT NULL COMMENT 'Числовий рівень доступу',
  `uss_add_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Статуси користувачів модуля df_';

--
-- Дамп данных таблицы `df_user_statuses`
--

INSERT INTO `df_user_statuses` (`uss_id`, `uss_name`, `uss_description`, `uss_access_level`, `uss_add_date`) VALUES
(1, 'SuperAdmin', 'Супер адміністратор', 1, '2024-05-04 14:45:11'),
(2, 'Admin', 'Адміністратор', 2, '2024-04-24 19:29:50'),
(3, 'User', 'Користувач', 3, '2024-05-04 14:42:53'),
(4, 'Viewer', 'Переглядач', 4, '2024-05-04 14:44:17'),
(5, 'Guest', 'Гість', 5, '2024-04-24 19:32:08');

-- --------------------------------------------------------

--
-- Структура таблицы `df_visitor_routes`
--

CREATE TABLE `df_visitor_routes` (
  `vr_id` int UNSIGNED NOT NULL,
  `vr_id_user` bigint UNSIGNED NOT NULL,
  `vr_ip` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `vr_uri` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `vr_user_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vr_queries_count` int UNSIGNED DEFAULT NULL COMMENT 'Количество запросов к БД. при посещении URI.',
  `vr_execution_time` float UNSIGNED NOT NULL COMMENT 'Час повного виконання URL запиту користувача в секундах з точністю до міліонних',
  `vr_add_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `df_departments`
--
ALTER TABLE `df_departments`
  ADD PRIMARY KEY (`dp_id`);

--
-- Индексы таблицы `df_distribution_scopes`
--
ALTER TABLE `df_distribution_scopes`
  ADD PRIMARY KEY (`dsc_id`);

--
-- Индексы таблицы `df_document_carrier_types`
--
ALTER TABLE `df_document_carrier_types`
  ADD PRIMARY KEY (`cts_id`);

--
-- Индексы таблицы `df_document_control_types`
--
ALTER TABLE `df_document_control_types`
  ADD PRIMARY KEY (`dct_id`),
  ADD UNIQUE KEY `uni_1` (`dct_name`);

--
-- Индексы таблицы `df_document_descriptions`
--
ALTER TABLE `df_document_descriptions`
  ADD PRIMARY KEY (`dds_id`);

--
-- Индексы таблицы `df_document_locations`
--
ALTER TABLE `df_document_locations`
  ADD PRIMARY KEY (`dlc_id`);

--
-- Индексы таблицы `df_document_resolutions`
--
ALTER TABLE `df_document_resolutions`
  ADD PRIMARY KEY (`drs_id`);

--
-- Индексы таблицы `df_document_senders`
--
ALTER TABLE `df_document_senders`
  ADD PRIMARY KEY (`dss_id`),
  ADD UNIQUE KEY `uni_1` (`dss_name`);

--
-- Индексы таблицы `df_document_statuses`
--
ALTER TABLE `df_document_statuses`
  ADD PRIMARY KEY (`dst_id`),
  ADD UNIQUE KEY `uni_1` (`dst_name`);

--
-- Индексы таблицы `df_document_titles`
--
ALTER TABLE `df_document_titles`
  ADD PRIMARY KEY (`dts_id`);

--
-- Индексы таблицы `df_document_types`
--
ALTER TABLE `df_document_types`
  ADD PRIMARY KEY (`dt_id`);

--
-- Индексы таблицы `df_incoming_documents_registry`
--
ALTER TABLE `df_incoming_documents_registry`
  ADD PRIMARY KEY (`idr_id`),
  ADD UNIQUE KEY `uni_1` (`idr_number`),
  ADD KEY `idr_document_format` (`idr_id_carrier_type`),
  ADD KEY `idr_assigned_departament` (`idr_id_assigned_departament`),
  ADD KEY `idr_description` (`idr_id_description`),
  ADD KEY `idr_document_type` (`idr_id_document_type`),
  ADD KEY `idr_outgoing_number` (`idr_id_outgoing_number`),
  ADD KEY `idr_resolution` (`idr_id_resolution`),
  ADD KEY `idr_responsible_user` (`idr_id_responsible_user`),
  ADD KEY `idr_sender` (`idr_id_sender`),
  ADD KEY `idr_status` (`idr_id_status`),
  ADD KEY `idr_title` (`idr_id_title`),
  ADD KEY `idr_user` (`idr_id_user`),
  ADD KEY `idr_document_location` (`idr_id_document_location`),
  ADD KEY `idr_assigned_user` (`idr_id_assigned_user`),
  ADD KEY `idr_execution_control` (`idr_id_execution_control`),
  ADD KEY `idr_term_of_execution` (`idr_id_term_of_execution`),
  ADD KEY `idr_recipient` (`idr_id_recipient`);

--
-- Индексы таблицы `df_internal_documents_registry`
--
ALTER TABLE `df_internal_documents_registry`
  ADD PRIMARY KEY (`inr_id`),
  ADD UNIQUE KEY `uni_1` (`inr_number`);

--
-- Индексы таблицы `df_outgoing_documents_registry`
--
ALTER TABLE `df_outgoing_documents_registry`
  ADD PRIMARY KEY (`odr_id`),
  ADD UNIQUE KEY `uni_1` (`odr_number`),
  ADD KEY `odr_registration_form_number` (`odr_registration_form_number`);

--
-- Индексы таблицы `df_registration_forms`
--
ALTER TABLE `df_registration_forms`
  ADD PRIMARY KEY (`rf_id`),
  ADD UNIQUE KEY `uni_1` (`rf_name`);

--
-- Индексы таблицы `df_terms_of_execution`
--
ALTER TABLE `df_terms_of_execution`
  ADD PRIMARY KEY (`toe_id`),
  ADD UNIQUE KEY `uni_1` (`toe_name`);

--
-- Индексы таблицы `df_users`
--
ALTER TABLE `df_users`
  ADD PRIMARY KEY (`us_id`),
  ADD UNIQUE KEY `uni_1` (`us_login`);

--
-- Индексы таблицы `df_users_rel_statuses`
--
ALTER TABLE `df_users_rel_statuses`
  ADD PRIMARY KEY (`usr_id`),
  ADD UNIQUE KEY `uni_1` (`usr_id_user`,`usr_id_status`),
  ADD KEY `usr_status` (`usr_id_status`);

--
-- Индексы таблицы `df_user_document_access`
--
ALTER TABLE `df_user_document_access`
  ADD PRIMARY KEY (`uda_id`);

--
-- Индексы таблицы `df_user_rel_departament`
--
ALTER TABLE `df_user_rel_departament`
  ADD PRIMARY KEY (`urd_id`),
  ADD KEY `urd_user` (`urd_id_user`),
  ADD KEY `urd_departament` (`urd_id_departament`);

--
-- Индексы таблицы `df_user_statuses`
--
ALTER TABLE `df_user_statuses`
  ADD PRIMARY KEY (`uss_id`),
  ADD UNIQUE KEY `uni_1` (`uss_name`);

--
-- Индексы таблицы `df_visitor_routes`
--
ALTER TABLE `df_visitor_routes`
  ADD PRIMARY KEY (`vr_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `df_departments`
--
ALTER TABLE `df_departments`
  MODIFY `dp_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `df_distribution_scopes`
--
ALTER TABLE `df_distribution_scopes`
  MODIFY `dsc_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `df_document_carrier_types`
--
ALTER TABLE `df_document_carrier_types`
  MODIFY `cts_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `df_document_control_types`
--
ALTER TABLE `df_document_control_types`
  MODIFY `dct_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `df_document_descriptions`
--
ALTER TABLE `df_document_descriptions`
  MODIFY `dds_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `df_document_locations`
--
ALTER TABLE `df_document_locations`
  MODIFY `dlc_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `df_document_resolutions`
--
ALTER TABLE `df_document_resolutions`
  MODIFY `drs_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `df_document_senders`
--
ALTER TABLE `df_document_senders`
  MODIFY `dss_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `df_document_statuses`
--
ALTER TABLE `df_document_statuses`
  MODIFY `dst_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `df_document_titles`
--
ALTER TABLE `df_document_titles`
  MODIFY `dts_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `df_document_types`
--
ALTER TABLE `df_document_types`
  MODIFY `dt_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT для таблицы `df_incoming_documents_registry`
--
ALTER TABLE `df_incoming_documents_registry`
  MODIFY `idr_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT для таблицы `df_internal_documents_registry`
--
ALTER TABLE `df_internal_documents_registry`
  MODIFY `inr_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `df_outgoing_documents_registry`
--
ALTER TABLE `df_outgoing_documents_registry`
  MODIFY `odr_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `df_registration_forms`
--
ALTER TABLE `df_registration_forms`
  MODIFY `rf_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `df_terms_of_execution`
--
ALTER TABLE `df_terms_of_execution`
  MODIFY `toe_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `df_users`
--
ALTER TABLE `df_users`
  MODIFY `us_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT для таблицы `df_users_rel_statuses`
--
ALTER TABLE `df_users_rel_statuses`
  MODIFY `usr_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT для таблицы `df_user_document_access`
--
ALTER TABLE `df_user_document_access`
  MODIFY `uda_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `df_user_rel_departament`
--
ALTER TABLE `df_user_rel_departament`
  MODIFY `urd_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `df_user_statuses`
--
ALTER TABLE `df_user_statuses`
  MODIFY `uss_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `df_visitor_routes`
--
ALTER TABLE `df_visitor_routes`
  MODIFY `vr_id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `df_incoming_documents_registry`
--
ALTER TABLE `df_incoming_documents_registry`
  ADD CONSTRAINT `idr_assigned_departament` FOREIGN KEY (`idr_id_assigned_departament`) REFERENCES `df_departments` (`dp_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_assigned_user` FOREIGN KEY (`idr_id_assigned_user`) REFERENCES `df_users` (`us_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_description` FOREIGN KEY (`idr_id_description`) REFERENCES `df_document_descriptions` (`dds_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_document_format` FOREIGN KEY (`idr_id_carrier_type`) REFERENCES `df_document_carrier_types` (`cts_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_document_location` FOREIGN KEY (`idr_id_document_location`) REFERENCES `df_departments` (`dp_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_document_type` FOREIGN KEY (`idr_id_document_type`) REFERENCES `df_document_types` (`dt_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_execution_control` FOREIGN KEY (`idr_id_execution_control`) REFERENCES `df_document_control_types` (`dct_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_outgoing_number` FOREIGN KEY (`idr_id_outgoing_number`) REFERENCES `df_outgoing_documents_registry` (`odr_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_recipient` FOREIGN KEY (`idr_id_recipient`) REFERENCES `df_users` (`us_id`) ON DELETE SET NULL ON UPDATE SET NULL,
  ADD CONSTRAINT `idr_resolution` FOREIGN KEY (`idr_id_resolution`) REFERENCES `df_document_resolutions` (`drs_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_responsible_user` FOREIGN KEY (`idr_id_responsible_user`) REFERENCES `df_users` (`us_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_sender` FOREIGN KEY (`idr_id_sender`) REFERENCES `df_document_senders` (`dss_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_status` FOREIGN KEY (`idr_id_status`) REFERENCES `df_document_statuses` (`dst_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_term_of_execution` FOREIGN KEY (`idr_id_term_of_execution`) REFERENCES `df_terms_of_execution` (`toe_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_title` FOREIGN KEY (`idr_id_title`) REFERENCES `df_document_titles` (`dts_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `idr_user` FOREIGN KEY (`idr_id_user`) REFERENCES `df_users` (`us_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `df_outgoing_documents_registry`
--
ALTER TABLE `df_outgoing_documents_registry`
  ADD CONSTRAINT `odr_registration_form_number` FOREIGN KEY (`odr_registration_form_number`) REFERENCES `df_registration_forms` (`rf_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `df_users_rel_statuses`
--
ALTER TABLE `df_users_rel_statuses`
  ADD CONSTRAINT `usr_status` FOREIGN KEY (`usr_id_status`) REFERENCES `df_user_statuses` (`uss_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `usr_user` FOREIGN KEY (`usr_id_user`) REFERENCES `df_users` (`us_id`);

--
-- Ограничения внешнего ключа таблицы `df_user_rel_departament`
--
ALTER TABLE `df_user_rel_departament`
  ADD CONSTRAINT `urd_departament` FOREIGN KEY (`urd_id_departament`) REFERENCES `df_departments` (`dp_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `urd_user` FOREIGN KEY (`urd_id_user`) REFERENCES `df_users` (`us_id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
