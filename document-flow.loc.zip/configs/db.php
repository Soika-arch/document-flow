<?php

// Конфігурація бази даних.

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

if (Production) {
	// Конфігурація для продакшена.

	define('DbHost', 'localhost');
	define('DbName', 'zorkiysv');
	define('DbUser', 'zorkiysv');
	define('DbPass', 'sjnKD8&p3Js-(sj');
	define('DbPrefix', 'df_'); // Префікс таблиць бази даних.
}
else {
	// Конфігурація для локального сервера.

	define('DbHost', 'localhost');
	define('DbName', 'petamicr');
	define('DbUser', 'admin');
	define('DbPass', '121010');
	define('DbPrefix', 'df_');
}
