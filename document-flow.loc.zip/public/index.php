<?php

// Точка входу в застосунок.

require_once '../index.php';
