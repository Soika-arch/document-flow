<?php

namespace libs\query_builder;

/**
 * Interface QueryInterface.
 */
interface QueryInterface
{
}
