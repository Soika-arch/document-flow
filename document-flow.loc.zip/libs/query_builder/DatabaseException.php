<?php

namespace libs\query_builder;

use RuntimeException;

/**
 * Database exception.
 */
final class DatabaseException extends RuntimeException
{
}
